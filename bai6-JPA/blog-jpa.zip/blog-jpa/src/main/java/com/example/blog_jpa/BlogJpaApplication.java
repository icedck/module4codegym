package com.example.blog_jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlogJpaApplication.class, args);
	}

}
