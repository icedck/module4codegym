package com.example.blog_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
